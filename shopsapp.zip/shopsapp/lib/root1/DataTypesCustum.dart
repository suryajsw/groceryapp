class DataBase{
  var userData;
  List<String> wishList;
  Map<String,dynamic> addToCart;
  double total ;
  double discountTotal;
  DataBase(this.userData,this.wishList,this.addToCart,this.total,this.discountTotal);
}